export class Image {
    constructor(
        public id: string,
        public title: string,
        public description: string,
        public thumbnail: string,
        public imageLink: string
    ) {

  }
}
